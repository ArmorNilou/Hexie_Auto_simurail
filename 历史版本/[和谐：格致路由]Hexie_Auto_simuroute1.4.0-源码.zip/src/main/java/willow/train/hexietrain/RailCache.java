package willow.train.hexietrain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.simibubi.create.content.trains.entity.TravellingPoint;
import com.simibubi.create.content.trains.graph.TrackEdge;
import com.simibubi.create.content.trains.graph.TrackGraph;
import com.simibubi.create.content.trains.graph.TrackNode;
import com.simibubi.create.content.trains.signal.SignalBoundary;
import com.simibubi.create.content.trains.signal.TrackEdgePoint;
import com.simibubi.create.content.trains.station.GlobalStation;
import net.createmod.catnip.data.Couple;

import net.minecraft.core.BlockPos;

/**
 * 第 2 块：铁路缓存。
 *
 * 只干三件事，全部借机械动力自己的机制：
 *   ① 找站点边 —— 让 Create 的 TravellingPoint 沿轨走，捕捉 STATION 边点事件，
 *      事件给的 Couple&lt;TrackNode&gt; 就是那条边的权威身份（不用坐标去猜）。
 *   ② 找铁路边序列 —— 让 Create 的 TravellingPoint 走一遍，用 ITrackSelector 记录它选了哪些边。
 *   ③ 找沿途边点 —— 从 TrackGraph 的边点注册表里取 STATION / SIGNAL，
 *      用 TrackEdgePoint.getLocationOn(edge) 判断它在不在本段某条边上，再换算成弧长 s。
 *
 * 不做方向判定（那是步骤③）、不做驱动、不碰红石。写好了等调用。
 */
public final class RailCache {

   // ================================================================ 数据结构

   // StationEdge 类已随站点边缓存一起删除（1.2.0，0 调用方）
   /** 路线的一段：某条边 + 它在本段里的起点弧长 + 是否反向走。 */
   public static final class Leg {
      public final TrackEdge edge;
      public final double startS;
      public final boolean reversed;

      /**
       * <b>预置走法（2026-11-23）</b>：这一段从 {@code exitNode} 离开，接着走 {@code nextEdge}。
       *
       * <p>这两个字段在<b>建路线的时候</b>就定死，运行期只查表 —— 于是"这个岔口该走哪一股"
       * 不需要在车上现算，也不再依赖"当前边在路线里排第几"（那条路在连续岔道上很脆）。
       * 最后一段两者都是 null，表示再往前就出路线了。
       */
      public TrackNode exitNode = null;
      public TrackEdge nextEdge = null;

      public Leg(TrackEdge edge, double startS, boolean reversed) {
         this.edge = edge;
         this.startS = startS;
         this.reversed = reversed;
      }

      public double length() {
         return CreateApi.length(this.edge);
      }

      public double endS() {
         return this.startS + this.length();
      }

      /** 把边上位置（从 node1 量起）换算成本段的弧长 s。 */
      public double arcOf(double positionOnEdge) {
         return this.reversed ? this.startS + (this.length() - positionOnEdge) : this.startS + positionOnEdge;
      }
   }

   /** 沿途边点：弧长 s + 对象 + 所在边。 */
   public static final class Hit {
      public final double s;
      public final TrackEdgePoint point;
      public final TrackEdge edge;
      public final boolean station;

      public Hit(double s, TrackEdgePoint point, TrackEdge edge, boolean station) {
         this.s = s;
         this.point = point;
         this.edge = edge;
         this.station = station;
      }

      public String name() {
         return CreateApi.nameOf(this.point);
      }
   }

   /** 一整段路线：有向边序列 + 沿途边点 + 站点所在弧长。 */
   public static final class Route {
      public final GlobalStation target;
      public final List<Leg> legs = new ArrayList<>();
      public final List<Hit> points = new ArrayList<>();
      public double total = 0.0;
      /** 目标站在本段上的弧长；NaN = 没在这段路上找到它 */
      public double stationS = Double.NaN;

      public Route(GlobalStation target) {
         this.target = target;
      }

      public boolean ready() {
         return !this.legs.isEmpty() && Double.isFinite(this.stationS);
      }

      public Leg legOf(TrackEdge e) {
         for (Leg l : this.legs) {
            if (sameLink(l.edge, e)) return l;   // 不比较对象：正反是不同对象
         }
         return null;
      }

      /**
       * <b>带游标的段定位（2026-11-23）</b>：优先"我上次所在的那一段"，其次"它的下一段"，
       * 实在对不上才全表扫。
       *
       * <p>为什么必须这样：{@link #legOf} 按"无序节点对"匹配并且只返回第一处。当同一段轨
       * 在一趟里出现两次（折返、环线、站场里两条并联轨共用同一对节点），每一拍都可能挑到
       * 不同的那一段，于是 {@code nextEdge} / {@code exitNode} 每拍在翻，喂给轴的 dest 也跟着翻。
       * 2026-11-23 20:51 那三次「想要=直7.00m 实际上了=直16.00m」就是这么来的：
       * 7m 那条的远端是 (-41,63,15.5)，可过岔那一刻 currentPath 已经是 (-48,63,15.5) ——
       * 中途被另一拍的判定覆盖过，然后 navigate() 照着 (-48) 把车送进了 16m 那条。
       *
       * <p>游标是单调往前的：轴跨过一个节点，游标就前进一段，不会跳回去。
       */
      public Leg legAt(TrackEdge e, int hint) {
         if (e == null || this.legs.isEmpty()) {
            return null;
         }
         if (hint >= 0 && hint < this.legs.size() && sameLink(this.legs.get(hint).edge, e)) {
            return this.legs.get(hint);
         }
         int next = hint + 1;
         if (next >= 0 && next < this.legs.size() && sameLink(this.legs.get(next).edge, e)) {
            return this.legs.get(next);
         }
         for (int i = 0; i < this.legs.size(); i++) {
            if (sameLink(this.legs.get(i).edge, e)) {
               return this.legs.get(i);
            }
         }
         return null;
      }

      public int indexOfLeg(Leg leg) {
         return leg == null ? -1 : this.legs.indexOf(leg);
      }

      /** 边上位置 → 本段弧长 s。车不在本段上返回 NaN。 */
      public double sOf(TrackEdge e, double positionOnEdge) {
         Leg l = legOf(e);
         if (l == null || e == null || !Double.isFinite(positionOnEdge)) return Double.NaN;
         // 车手上的边可能是这条轨的反向对象，position 是从它自己的 node1 量的，要翻过来
         double pos = (e.node1 == l.edge.node1) ? positionOnEdge : (l.length() - positionOnEdge);
         return l.arcOf(pos);
      }

      /**
       * 距目标站还有多远（沿本段前进方向的弧长差）。
       * 返回**带符号**：正 = 站还在前方；负 = 已经开过站了。
       * 绝不绕环 —— 过站必须能被上层看见。
       */
      public double remaining(TrackEdge e, double positionOnEdge) {
         double a = sOf(e, positionOnEdge);
         if (!Double.isFinite(a) || !Double.isFinite(this.stationS)) return Double.NaN;
         return this.stationS - a;
      }

      public boolean passed(TrackEdge e, double positionOnEdge) {
         double d = remaining(e, positionOnEdge);
         return Double.isFinite(d) && d < 0.0;
      }

      /**
       * 路线里 edge 的下一段：走到这条边尽头，该接着走哪条。
       * edge 不在本段上、或它已经是最后一段 → null（后者表示再往前就出路线了）。
       */
      public TrackEdge nextEdgeAfter(TrackEdge e) {
         for (int i = 0; i < this.legs.size(); i++) {
            if (sameLink(this.legs.get(i).edge, e)) {
               return i + 1 < this.legs.size() ? this.legs.get(i + 1).edge : null;
            }
         }
         return null;
      }

      /** 在这条 leg 里已经走了多少米（从 leg 起点算）。不在本段上 → NaN。 */
      public double posInLeg(TrackEdge e, double positionOnEdge) {
         Leg l = legOf(e);
         if (l == null) return Double.NaN;
         double s = sOf(e, positionOnEdge);
         return Double.isFinite(s) ? s - l.startS : Double.NaN;
      }

      /** 车头到这条 leg 尽头（= 下一个岔口/节点）还剩多少米。不算兜底，算不出来就是 NaN。 */
      public double remainingToLegEnd(TrackEdge e, double positionOnEdge) {
         Leg l = legOf(e);
         if (l == null) return Double.NaN;
         double used = posInLeg(e, positionOnEdge);
         return Double.isFinite(used) ? l.length() - used : Double.NaN;
      }

      /** s 之后最近的信号边点（步骤⑤用）。 */
      public Hit nextSignalAfter(double s) {
         Hit best = null;
         for (Hit h : this.points) {
            if (h.station || h.s < s) continue;
            if (best == null || h.s < best.s) best = h;
         }
         return best;
      }

      public Hit nextStationAfter(double s) {
         Hit best = null;
         for (Hit h : this.points) {
            if (!h.station || h.s < s) continue;
            if (best == null || h.s < best.s) best = h;
         }
         return best;
      }

      /**
       * <b>把每个岔口该怎么走预先定死。</b>
       *
       * <p>对路线里相邻的两段求它们的共用节点 J：{@code legs[i].exitNode = J}，
       * {@code legs[i].nextEdge = legs[i+1].edge}。运行期每根轴只要问"我这段的出口节点和下一段是哪条"，
       * 再取下一条边的<b>远端节点</b>当 `currentPath` 喂进去 —— 该岔口就定了。
       *
       * <p>这就是"每根轴只在岔口选一次，上对了路就不用管了"能成立的前提：
       * 一旦轴落到那条边上，轨道自身会把它约束住，不需要保持、不需要锁、不需要算腿长。
       */
      public void planTurnouts() {
         for (int i = 0; i < this.legs.size(); i++) {
            Leg l = this.legs.get(i);
            if (i + 1 >= this.legs.size()) {
               l.exitNode = null;
               l.nextEdge = null;
               continue;
            }
            Leg n = this.legs.get(i + 1);
            l.exitNode = sharedNode(l.edge, n.edge);
            l.nextEdge = n.edge;
         }
      }

      /** 两条边的共用节点（节点对象身份，来自同一张图）。没有就 null。 */
      private static TrackNode sharedNode(TrackEdge a, TrackEdge b) {
         if (a == null || b == null) {
            return null;
         }
         if (a.node1 != null && (a.node1 == b.node1 || a.node1 == b.node2)) {
            return a.node1;
         }
         if (a.node2 != null && (a.node2 == b.node1 || a.node2 == b.node2)) {
            return a.node2;
         }
         return null;
      }

      public String describe() {
         return (this.target == null ? "-" : this.target.name)
            + " 边数=" + this.legs.size()
            + " 总长=" + String.format("%.1f", this.total)
            + " 站点弧长=" + (Double.isFinite(this.stationS) ? String.format("%.1f", this.stationS) : "NaN")
            + " 边点=" + this.points.size();
      }
   }


   // ================================================================ 站点边缓存（1.2.0 删除）
   // 原来这里有一个 StationEdge/STATION_EDGES 图级缓存 + stationEdge(...) 探针，
   // 但全类外部【0 个调用方】（铁律 11 的死代码）。距站唯一来源是 RailSearch 的路线弧长。

   public static Route buildRoute(TrackGraph g, GlobalStation target, List<Couple<TrackNode>> couples) {
      Route route = new Route(target);
      if (g == null || couples == null || couples.isEmpty()) return route;

      double acc = 0.0;
      for (Couple<TrackNode> c : couples) {
         if (c == null) continue;
         TrackNode in = c.getFirst();
         TrackNode out = c.getSecond();
         TrackEdge e = CreateApi.edgeBetween(g, in, out);
         if (e == null) continue;
         boolean reversed = (e.node1 != in);
         route.legs.add(new Leg(e, acc, reversed));
         acc += CreateApi.length(e);
      }
      route.total = acc;

      collectPoints(g, route);
      route.planTurnouts();
      return route;
   }

   /**
    * 把现成的 Leg 列表装成 Route。弧长原点由调用方决定
    * （RailSearch 的约定是：原点 = 车此刻的位置）。
    */
   public static Route assemble(TrackGraph g, GlobalStation target, List<Leg> legs) {
      Route route = new Route(target);
      if (legs != null) route.legs.addAll(legs);
      double end = 0.0;
      for (Leg l : route.legs) {
         double e = l.endS();
         if (e > end) end = e;
      }
      route.total = end;
      collectPoints(g, route);
      route.planTurnouts();
      return route;
   }

   /** 两条边是不是同一段物理轨道（节点对无序相等）。正反方向在 Create 里是两个不同对象。 */
   public static boolean sameLink(TrackEdge a, TrackEdge b) {
      if (a == null || b == null) return false;
      if (a == b) return true;
      return (a.node1 == b.node1 && a.node2 == b.node2)
          || (a.node1 == b.node2 && a.node2 == b.node1);
   }

   // ================================================================ 内部

   private static void collectPoints(TrackGraph g, Route route) {
      for (GlobalStation st : CreateApi.stations(g)) {
         addHit(route, st, true);
      }
      for (SignalBoundary sg : CreateApi.signals(g)) {
         addHit(route, sg, false);
      }
      route.points.sort((x, y) -> Double.compare(x.s, y.s));

      for (Hit h : route.points) {
         if (h.point == route.target) {
            route.stationS = h.s;
            break;
         }
      }
   }

   private static void addHit(Route route, TrackEdgePoint ep, boolean station) {
      if (ep == null) return;
      for (Leg l : route.legs) {
         double pos = CreateApi.positionOn(ep, l.edge);
         if (!Double.isFinite(pos)) continue;
         route.points.add(new Hit(l.arcOf(pos), ep, l.edge, station));
         return;
      }
   }

   // ================================================================ 实例缓存（每个调度器一份）

   private String routeKey = null;
   private Route route = null;

   public Route route() {
      return this.route;
   }

   public boolean holds(String key) {
      return key != null && key.equals(this.routeKey) && this.route != null;
   }

   public void store(String key, Route r) {
      this.routeKey = key;
      this.route = r;
   }

   public void clear() {
      this.routeKey = null;
      this.route = null;
   }

   public String key() {
      return this.routeKey;
   }
}
